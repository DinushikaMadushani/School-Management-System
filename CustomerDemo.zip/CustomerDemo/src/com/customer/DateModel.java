package com.customer;

public class DateModel {
	private String Date;
	
	
	public DateModel(String Date) {
		
		this.Date = Date;
			
	}


	public String getDate() {
		return Date;
	}

}
